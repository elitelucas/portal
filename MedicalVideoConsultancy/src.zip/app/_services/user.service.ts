import { filter } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../environments/environment";
const baseUrl = environment.baseUrl + "users";
@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }


  getAdmins() {
    console.log('adfadf')
    let adminsUrl= baseUrl+"/super-admins";
    return this.http.get<any>(adminsUrl);
  }
  getAdminById(adminId) {
    let adminsUrl= baseUrl+"/super-admins/"+adminId;
    return this.http.get<any>(adminsUrl);
  }

  createAdmin(data){
    let adminsUrl= baseUrl+"/super-admins";
    return this.http.post<any>(adminsUrl,data);
  }
  updateAdmin(data,adminId){
    let adminsUrl= baseUrl+"/super-admins/"+adminId;
    return this.http.put<any>(adminsUrl,data);
  }

  
  getAdminFilterData(filterValue) {
    let filterUrl=baseUrl+"/filterAdmin/"+filterValue;
    return this.http.get<any>(filterUrl);
  }

   //Delete administrator in admins collection
   deleteAdmin(providerId) {
    let deleteAdmin=baseUrl+"/deleteAdmin/"+providerId;
    return this.http.delete<any>(deleteAdmin);
  }

 
}
