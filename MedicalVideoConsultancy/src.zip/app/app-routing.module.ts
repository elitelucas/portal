
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SitesComponent } from './component/sites/sites.component';
import { AdminUpdateComponent } from './component/sites/admin-update/admin-update.component';

import { ClientsComponent } from './component/clients/clients.component';
import { CommunicationsComponent } from './component/communications/communications.component';
import { LeadsComponent } from './component/leads/leads.component';
import { AfterhoursComponent } from './component/afterhours/afterhours.component';
import { LayoutComponent } from './layout/layout.component';
const routes: Routes = [
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: '',
        redirectTo: 'sites',
        pathMatch: 'full'
      },
      {
        path:'sites',
        component:SitesComponent
      },
      {
        path:'clients',
        component:ClientsComponent
      },
      {
        path:'leads',
        component:LeadsComponent
      },
      {
        path:'afterhours',
        component:AfterhoursComponent
      },
      {
        path:'communications',
        component:CommunicationsComponent
      },
      {
        path: 'admin-update/:data',
        component: AdminUpdateComponent,
      },
    ]
  },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
