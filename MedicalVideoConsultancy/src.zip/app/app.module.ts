import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common'; 
import { HttpClientModule } from '@angular/common/http';

import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';


import { AppComponent } from './app.component';
import { SitesComponent } from './component/sites/sites.component';
import { ClientsComponent } from './component/clients/clients.component';
import { AfterhoursComponent } from './component/afterhours/afterhours.component';
import { LeadsComponent } from './component/leads/leads.component';
import { CommunicationsComponent } from './component/communications/communications.component';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { DemoMaterialModule } from './demo-material-module';
import { HeaderComponent } from './layout/header/header.component';
import { LayoutComponent } from './layout/layout.component';




@NgModule({
  declarations: [
    AppComponent,
    SitesComponent,
    ClientsComponent,
    AfterhoursComponent,
    LeadsComponent,
    CommunicationsComponent,
    SidebarComponent,
    HeaderComponent,
    LayoutComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    DemoMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    SharedModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
