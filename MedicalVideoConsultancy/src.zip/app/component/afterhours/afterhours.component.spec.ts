import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AfterhoursComponent } from './afterhours.component';

describe('AfterhoursComponent', () => {
  let component: AfterhoursComponent;
  let fixture: ComponentFixture<AfterhoursComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AfterhoursComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AfterhoursComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
