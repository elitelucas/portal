import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-afterhours',
  templateUrl: './afterhours.component.html',
  styleUrls: ['./afterhours.component.css']
})
export class AfterhoursComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
