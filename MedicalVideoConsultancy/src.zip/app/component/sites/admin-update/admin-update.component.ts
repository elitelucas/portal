import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { UserService } from './../../../_services/user.service';
import  Swal  from 'sweetalert2';



@Component({
  selector: 'app-admin-update',
  templateUrl: './admin-update.component.html',
  styleUrls: ['./admin-update.component.css']
})
export class AdminUpdateComponent implements OnInit {
  registerTitle:String;
  registerForm:FormGroup;
  submitted=false;
  passSubmitted=false;

  formData:any;
  userId:any;

  constructor(
    private route:ActivatedRoute,
    private formBuilder: FormBuilder,
    private userService:UserService
    ) {
      
    this.route.params.subscribe(data=>{
      if(data.data==='new'){
        this.registerTitle="New"
      }else{
        this.registerTitle="Update";
        console.log('data.data')
        console.log(data.data)
        this.userService.getAdminById(data.data).subscribe(res=>{
          console.log('res')
          console.log(res)
          this.formData=res;
          this.userId=this.formData._id;
          this.registerForm = this.formBuilder.group({
            type: [this.formData? this.formData.type:'', Validators.required],
            name: [this.formData? this.formData.name:'', Validators.required],
            contact: [this.formData? this.formData.contact:'', [Validators.required]],
            address: [this.formData? this.formData.address:'', [Validators.required]],
            check: [this.formData? this.formData.check:'', [Validators.required]],
            active: [this.formData? this.formData.active:'', [Validators.required]],
            notes: [this.formData? this.formData.notes:'', [Validators.required]],
            requirement: [this.formData? this.formData.requirement:'', Validators.required],
          });
        })
      }
    })
   }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      type: [this.formData? this.formData.type:'', Validators.required],
      name: [this.formData? this.formData.name:'', [Validators.required]],
      contact: [this.formData? this.formData.contact:'', [Validators.required]],
      address: [this.formData? this.formData.address:'', [Validators.required]],
      check: [this.formData? this.formData.check:'', [Validators.required]],
      active: [this.formData? this.formData.active:'', [Validators.required]],
      notes: [this.formData? this.formData.notes:'', [Validators.required]],
      requirement: [this.formData? this.formData.requirement:'', Validators.required],
    });

  }
  get f() { return this.registerForm.controls; }


  onSubmit(){
    console.log('wwwww')
    this.submitted=true;
    // stop here if form is invalid
    if (this.registerForm.invalid) {
      console.log('sddf')
      return;
    }

    if(this.formData){
      console.log('ddd')
      return
      this.userService.updateAdmin(this.registerForm.value,this.userId).subscribe(res=>{
        if(res){
          Swal.fire('Updated Successfully!')
          this.submitted=false;
                  
        }
      })
    }else{
      console.log('adfadfadf')
      return;
      this.userService.createAdmin(this.registerForm.value).subscribe(res=>{
        if(res){
          this.userId=res._id;
          Swal.fire('Inserted Successfully!')
          this.submitted=false;
        }
      })
    }
  }

  onReset(){
    this.submitted = false;
    this.registerForm.reset();
  }

}

