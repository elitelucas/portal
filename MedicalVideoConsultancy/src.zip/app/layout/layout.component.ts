import { MediaMatcher } from '@angular/cdk/layout';
import {
  ChangeDetectorRef,
  Component,
  OnDestroy,
  AfterViewInit, OnInit
} from '@angular/core';
import { MenuItems } from '../shared/sidebar-item/menu-items';

/** @title Responsive sidenav */
@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {

  constructor(
  ) {

  }

  ngOnInit() {}
}
