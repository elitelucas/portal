import {
  ChangeDetectorRef,
  Component,
  EventEmitter,
  NgZone,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { DomSanitizer } from "@angular/platform-browser";
import { Router } from "@angular/router";
import { MenuItems } from '../../shared/sidebar-item/menu-items';



@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {


  Menu:any;

  constructor(
    public menuItems: MenuItems,
    private router: Router
  ) {

  }

  ngOnInit(): void {
    this.Menu=this.menuItems.getMenuitem();
  }

}
