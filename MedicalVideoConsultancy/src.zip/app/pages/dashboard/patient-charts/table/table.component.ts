
import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject, Subscription } from 'rxjs';

import {ProviderService} from '../../../../_services/provider.service'


interface Country {
  id?: number;
  name: string;
  flag: string;
  area: number;
  population: number;
}

const COUNTRIES: Country[] = [
  {
    name: 'Russia',
    flag: 'f/f3/Flag_of_Russia.svg',
    area: 17075200,
    population: 146989754
  },
];

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent {

  page = 1;
  pageSize = 4;
  collectionSize = COUNTRIES.length;
  countries: Country[];

  constructor(private ProviderService:ProviderService) {
    this.refreshCountries();
    this.ProviderService.getAllPatientsData().subscribe((posts) => {
      // this.posts = posts;
      console.log(posts)
  })
}

  refreshCountries() {
    this.countries = COUNTRIES
      .map((country, i) => ({id: i + 1, ...country}))
      .slice((this.page - 1) * this.pageSize, (this.page - 1) * this.pageSize + this.pageSize);
  }
  detailPatient(id){
    console.log('id')
    console.log(id)
  }
}
