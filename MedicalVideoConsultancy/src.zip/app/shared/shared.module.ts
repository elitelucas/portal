import { NgModule } from '@angular/core';

import { MenuItems } from './sidebar-item/menu-items';
import { AccordionAnchorDirective, AccordionLinkDirective, AccordionDirective } from './accordion';



import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
  ],
  imports: [
    CommonModule,
    FormsModule,
 
  ],
  exports: [
    CommonModule,
    AccordionAnchorDirective,
    AccordionLinkDirective,
    AccordionDirective,
    FormsModule,
   

   ],
  providers: [ MenuItems ]
})
export class SharedModule { }
