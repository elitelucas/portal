import { Injectable } from '@angular/core';

export interface Menu {
  state: string;
  name: string;
  type: string;
  icon: string;
}
const MENUITEMS_USER = [
  { state: 'sites', name: 'Sites', type: 'link', icon: 'https://img.icons8.com/doodle/48/000000/doctor-male.png' },
  { state: 'clients', name: 'Clients', type: 'link', icon: 'https://img.icons8.com/doodle/48/000000/doctor-male.png' },
  { state: 'afterhours', name: 'Afterhours', type: 'link', icon: 'https://img.icons8.com/doodle/48/000000/doctor-male.png' },
  { state: 'leads', name: 'Leads', type: 'link', icon: 'https://img.icons8.com/doodle/48/000000/doctor-male.png' },
  { state: 'communications', name: 'Communications', type: 'link', icon: 'https://img.icons8.com/doodle/48/000000/doctor-male.png' },
];

@Injectable()
export class MenuItems {
  getMenuitem(): Menu[] {
      return MENUITEMS_USER;
  }
}
