import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-patient-charts',
  templateUrl: './patient-charts.component.html',
  styleUrls: ['./patient-charts.component.css']
})
export class PatientChartsComponent implements OnInit {

  constructor() { 

  }

  ngOnInit(): void {
  }

}
