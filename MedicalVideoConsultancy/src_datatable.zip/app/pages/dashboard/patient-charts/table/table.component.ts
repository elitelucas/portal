import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Subject, Subscription } from 'rxjs';

import {ProviderService} from '../../../../_services/provider.service'

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit{
  title = 'datatables';
  dtOptions: DataTables.Settings = {};
  posts;
  showContent;
  count=[];

  constructor(private ProviderService:ProviderService) {
    this.ProviderService.getAllPatientsData().subscribe((posts) => {
        this.posts = posts;
        console.log(posts)
    });
  }

  ngOnInit(): void {
    setTimeout(()=>this.showContent=true, 250);
    const that = this;
    this.dtOptions = {

      pagingType: 'full_numbers',
      pageLength: 5,
      processing: true,
      language: {
        searchPlaceholder: 'DNI or fullname',
      },
    };
  }
  detailPatient(id){
    console.log('id')
    console.log(id)
  }

}
